package kr.spring.member.domain;

public class FollowVO {
	private int f_activeuser;
	private int f_passiveuser;
	
	public int getF_activeuser() {
		return f_activeuser;
	}
	public void setF_activeuser(int f_activeuser) {
		this.f_activeuser = f_activeuser;
	}
	public int getF_passiveuser() {
		return f_passiveuser;
	}
	public void setF_passiveuser(int f_passiveuser) {
		this.f_passiveuser = f_passiveuser;
	}
}