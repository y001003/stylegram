package kr.spring.mainboardlikes.domain;

public class MainBoardLikeVO {
	private int mb_num;
	private int m_num;
	
	public int getMb_num() {
		return mb_num;
	}
	public void setMb_num(int mb_num) {
		this.mb_num = mb_num;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
}