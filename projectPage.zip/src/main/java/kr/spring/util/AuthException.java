package kr.spring.util;

public class AuthException extends Exception{

}