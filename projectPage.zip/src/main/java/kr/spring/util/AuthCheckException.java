package kr.spring.util;

public class AuthCheckException extends Exception{

}